package Hechizos;

import Personajes.Personaje;

public interface HechizoStrategy {
	void ejecutar(Personaje p);

}