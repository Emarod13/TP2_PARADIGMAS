package Objetos;

import Personajes.Personaje;

public abstract class Pocion {
	public abstract void consumir(Personaje p);

}
