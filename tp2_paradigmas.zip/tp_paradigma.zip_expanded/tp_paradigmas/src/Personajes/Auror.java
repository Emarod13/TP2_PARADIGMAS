package Personajes;

public class Auror extends Mago {

	public Auror(String nombre, int nivel_de_magia, int puntos_de_vida) {
		super(nombre, nivel_de_magia, puntos_de_vida);
		// TODO Auto-generated constructor stub
	}

}
