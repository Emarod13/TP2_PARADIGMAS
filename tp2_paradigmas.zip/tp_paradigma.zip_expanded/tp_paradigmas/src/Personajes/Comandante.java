package Personajes;

public class Comandante extends Mortifago {
	
	private static final int NIVEL = 3;
	private static final int PUNTOS_DE_VIDA = 500;
	public Comandante(String nombre) {
		super(nombre, NIVEL, PUNTOS_DE_VIDA);
		// TODO Auto-generated constructor stub
	}

}
