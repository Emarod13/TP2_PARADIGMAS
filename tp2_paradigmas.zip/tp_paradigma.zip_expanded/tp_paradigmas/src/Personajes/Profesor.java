package Personajes;

public class Profesor extends Mago{

	private static String nombre;
	private static int nivel_de_magia = 2;
	private static int puntos_de_vida = 500;
	
	public Profesor() {
		super(nombre, nivel_de_magia, puntos_de_vida);
		// TODO Auto-generated constructor stub
	}

}
