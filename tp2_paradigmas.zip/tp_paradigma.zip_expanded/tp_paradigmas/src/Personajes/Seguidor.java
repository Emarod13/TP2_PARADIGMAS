package Personajes;

public class Seguidor extends Mortifago{

	public Seguidor(String nombre, int nivel_de_magia, int puntos_de_vida) {
		super(nombre, nivel_de_magia, puntos_de_vida);
		// TODO Auto-generated constructor stub
	}

}
