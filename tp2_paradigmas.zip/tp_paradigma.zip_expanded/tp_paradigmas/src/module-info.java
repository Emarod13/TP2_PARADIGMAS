/**
 * 
 */
/**
 * 
 */
module tp_paradigmas {
}